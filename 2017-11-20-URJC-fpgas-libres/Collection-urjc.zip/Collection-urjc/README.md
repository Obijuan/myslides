# OSHWDem-17 Collection

[![Icestudio](https://img.shields.io/badge/collection-icestudio-blue.svg)](https://github.com/FPGAwars/icestudio)
![Version](https://img.shields.io/badge/version-v0.1.0-orange.svg)

Demo realizada en la OSHWDem 2017.

## Install

* Download the collection
* Install the collection: *Tools > Collections > Add*
* Load the collection: *Select > Collection*




## Authors
* [Juan Gonzalez-Gomez (Obijuan)](https://github.com/Obijuan)


## License

Licensed under [GPL-2.0](https://opensource.org/licenses/GPL-2.0).
